id -Gnz $FT_USER | tr '\0' ',' | sed 's/\(.*\),/\1/'
